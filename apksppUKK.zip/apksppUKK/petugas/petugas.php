<?php
session_start();
if(empty($_SESSION['id_petugas'])){
	echo"<script>alert('maaf anda belum login'); window.location.assign('../index2.php');
	</script>";
}
if($_SESSION['level']!='petugas'){
	echo"<script>alert('maaf anda bukan admin'); window.location.assign('../index2.php');
	</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Pembayaran spp</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">


	<h3>Aplikasi pembayaran spp</h3>
	<div class="alert alert-info">
		ANDA LOGIN SEBAGAI PETUGAS : <b><?= $_SESSION['nama_petugas']?></b>
	</div>

	<a href="petugas.php" class="btn btn-primary">Petugas</a>
    <a href="petugas.php?url=pembayaran" class="btn btn-primary">PEMBAYARAN</a>
    <a href="petugas.php?url=logout" class="btn btn-primary">LOGOUT</a>

    <div class="card mt-2">
    	<div class="card-body">
    		<?php
    		$file = @$_GET['url'];
    		if(empty($file)){
    			echo "<h4>selamat datang petugas</h4>";
    			echo "aplikasi pembayaran spp";
    		}else{
    			include $file.'.php';
    		}

    		 ?>
    		
    	</div>
    </div>

</div>

<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
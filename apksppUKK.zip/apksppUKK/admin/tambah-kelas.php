<h5>HALAMAN TAMBAH DATA KELAS</h5>
<a href="?url=kelas" class="btn btn-primary">kembali</a>
<hr>
<form method="post" action="?url=proses-tambah-kelas">
	<div class="form-group mb-2">
		<label>nama kelas</label>
		<input type="text" name="nama_kelas" class="form-control" placeholder="masukan kelas anda" required>
	</div>
	<div class="form-group mb-2">
		<label>komptensi keahlian</label>
		<input type="text" name="kompetensi_keahlian" class="form-control" placeholder="masukan komptensi keahlian anda" required>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">SIMPAN</button>
		<button type="reset" class="btn btn-danger">KOSONGKAN</button>
	</div>
	
</form>
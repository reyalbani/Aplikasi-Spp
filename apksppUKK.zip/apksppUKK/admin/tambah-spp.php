<h5>HALAMAN TAMBAH DATA SPP</h5>
<a href="?url=spp" class="btn btn-primary">kembali</a>
<hr>
<form method="post" action="?url=proses-tambah-spp">
	<div class="form-group mb-2">
		<label>tahun</label>
		<input type="number" name="tahun" maxlength="4" class="form-control" placeholder="masukan tahun anda" required>
	</div>
	<div class="form-group mb-2">
		<label>nominal</label>
		<input type="number" name="nominal" maxlength="13" class="form-control" placeholder="masukan nominal anda" required>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">SIMPAN</button>
		<button type="reset" class="btn btn-danger">KOSONGKAN</button>
	</div>
	
</form>
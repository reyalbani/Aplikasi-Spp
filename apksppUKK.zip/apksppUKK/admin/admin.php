<?php
session_start();
if(empty($_SESSION['id_petugas'])){
	echo"<script>alert('maaf anda belum login'); window.location.assign('../index2.php');
	</script>";
}
if($_SESSION['level']!='admin'){
	echo"<script>alert('maaf anda bukan admin'); window.location.assign('../index2.php');
	</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Pembayaran spp</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<link rel="icon" href="spp.png" type="image/x-icon" />
</head>
<body>
<div class="container mt-5">


	<h3>Aplikasi pembayaran spp</h3>
	<div class="alert alert-info">
		ANDA LOGIN SEBAGAI ADMIN : <b><?= $_SESSION['nama_petugas'] ?></b>
	</div>

	<a href="admin.php" class="btn btn-primary">ADMIN</a>
	<a href="admin.php?url=spp" class="btn btn-primary">SPP</a>
    <a href="admin.php?url=kelas" class="btn btn-primary">KELAS</a>
    <a href="admin.php?url=siswa" class="btn btn-primary">SISWA</a>
    <a href="admin.php?url=petugas" class="btn btn-primary">PETUGAS</a>
    <a href="admin.php?url=pembayaran" class="btn btn-primary">PEMBAYARAN</a>
    <a href="admin.php?url=laporan" class="btn btn-primary">LAPORAN</a>
    <a href="admin.php?url=logout" class="btn btn-primary">LOGOUT</a>

    <div class="card mt-2">
    	<div class="card-body">
    		<?php
    		$file = @$_GET['url'];
    		if(empty($file)){
    			echo "<h4>selamat datang di halaman ADMIN </h4>";
    			echo "aplikasi pembayaran SPP dibuat untuk mempermudah pembayaran siswa / siswi di sekolah";
    		}else{
    			include $file.'.php';
    		}

    		 ?>
    	</div>
    </div><hr>
</div>

<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$id_spp = $_GET['id_spp'];
include'../koneksi.php';
$sql = "SELECT*FROM spp WHERE id_spp='$id_spp'";
$query = mysqli_query($koneksi, $sql);
$data = mysqli_fetch_array($query);
?>
<h5>HALAMAN EDIT DATA SPP</h5>
<a href="?url=spp" class="btn btn-primary">kembali</a>
<hr>
<form method="post" action="?url=proses-edit-spp&id_spp=<?= $id_spp; ?>">
	<div class="form-group mb-2">
		<label>tahun</label>
		<input value="<?= $data['tahun'] ?>" type="number" name="tahun" maxlength="4" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>nominal</label>
		<input value="<?= $data['nominal'] ?>" type="number" name="nominal" maxlength="13" class="form-control" required>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">SIMPAN</button>
		<button type="reset" class="btn btn-danger">KOSONGKAN</button>
	</div>
	
</form>
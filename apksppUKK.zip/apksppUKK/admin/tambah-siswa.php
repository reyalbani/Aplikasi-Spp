<h5>HALAMAN TAMBAH DATA SISWA</h5>
<a href="?url=siswa" class="btn btn-primary">kembali</a>
<hr>
<form method="post" action="?url=proses-tambah-siswa">
	<div class="form-group mb-2">
		<label>Nisn</label>
		<input type="number" name="nisn" class="form-control" placeholder="masukan nisn anda" required>
	</div>
	<div class="form-group mb-2">
		<label>nis</label>
		<input type="number" name="nis"  class="form-control" placeholder="masukan nis anda" required>
	</div>
	<div class="form-group mb-2">
		<label>nama</label>
		<input type="text" name="nama"  class="form-control" placeholder="masukan nama anda" required>
	</div>
	<div class="form-group mb-2">
		<label>kelas</label>
		<select name="id_kelas" class="form-control" required>
			<option value="">pilih kelas</option>
			<?php
			include'../koneksi.php';
			$kelas = mysqli_query($koneksi, "SELECT*FROM kelas ORDER by nama_kelas ASC");
			foreach($kelas as $data_kelas){
			 ?>

			 <option value="<?= $data_kelas['id_kelas'] ?>"> <?= $data_kelas['nama_kelas']; ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="form-group mb-2">
		<label>alamat</label>
		<textarea name="alamat" class="form-control" required></textarea>
	</div>
	<div class="form-group mb-2">
		<label>No telp</label>
		<input type="number" name="no_telp" class="form-control" placeholder="masukan no telp anda" required>
	</div>
	<div class="form-group mb-2">
		<label>spp</label>
		<select name="id_spp" class="form-control" required>
			<option value="">pilih spp</option>
			<?php
			include'../koneksi.php';
			$spp = mysqli_query($koneksi, "SELECT*FROM spp ORDER by id_spp ASC");
			foreach($spp as $data_spp){
			 ?>

			 <option value="<?= $data_spp['id_spp'] ?>"> <?= $data_spp['tahun']; ?> | <?= number_format($data_spp['nominal'],2,',',','); ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-success">SIMPAN</button>
		<button type="reset" class="btn btn-danger">KOSONGKAN</button>
	</div>
	
</form>
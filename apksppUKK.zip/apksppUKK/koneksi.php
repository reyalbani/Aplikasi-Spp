9<?php
$koneksi = mysqli_connect('localhost','root','','database_spp');

if(!$koneksi){
	echo"koneksi anda gagal";
}
?>
<?php
class vehicle{
	protected $name;
	protected $year_release;

}

class automobile extends vehicle{
		protected $total_wheel;


		public set_year_release(){
			$this->year_release = 2006;
		}
}
$avanza = new automobile;
$avanza-> set_year_release();

?>
<?php
class animal{
    public $name = "blacki";
    public $feet = 2;
    public $sound = "guk-guk";

    public function make_sound(){
        echo $this->sound;
    }

    public function walk(){
        echo "Berjalan";
    }
    public function addfoot($a){
        $this->feet += $a;
    }
    public function get_feet(){
        return $this->feet;
    }
}
$cat = new animal();
echo $cat->name;
echo $cat->feet;
$cat->addfoot(2);
echo $cat->feet
/ $cat = new animal();
 echo $cat->get_feet();

class person{
    private $nama = "ucup";
    private $birthdate = "26-04-2005";
    private $hobi = "Badminton";
    private $alamat = "Konoha";
    private $gaji = 4000000;
    private $matkul = ["B.Arab","Algortima","Matematika","Kalkulus"];
    public function get_name(){
        $this->nama;
    }
    public function get_gaji($g){
        $this->gaji = $g;
        return $this->gaji;
    }
    public function tentukan_namanya($a){
        $this->nama = $a;
        return $this->nama;
    }
    public function tentukan_matkul($m){
        $this->matkul = $m;
        return $this->matkul;
    }
    

}
$dosen = new person();
$matkul = ["inggris","pancasila","literasi"];
echo "Dosen";
echo $dosen->get_gaji(1000000);
echo $dosen->tentukan_matkul($matkul);

class animal{
    private $name = "fulan";
    private $feet = "2";
    private $sound = "woy";

    public function __construct($name,$sound){
        $this->name = $name;
        $this->sound = $sound;
    }
    public function get_name(){
        return $this->name;
    }
    public function make_sound(){
        return $this->sound;
    }
}
$cat = new animal("kity","meong");
echo $cat->get_name();
echo $cat->make_sound();
?>

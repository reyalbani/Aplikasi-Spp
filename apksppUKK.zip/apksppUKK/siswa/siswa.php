<?php
session_start();
if(empty($_SESSION['nisn'])){
	echo"<script>alert('maaf anda belum login'); window.location.assign('../index.php');
	</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Pembayaran spp</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">


	<h3>Aplikasi pembayaran spp</h3>
	<div class="alert alert-info">
		ANDA LOGIN SEBAGAI SISWA : <b><?= $_SESSION['nama'] ?></b>
	</div>

	<a href="siswa.php" class="btn btn-primary">SISWA</a>
    <a href="siswa.php?url=logout" class="btn btn-primary">LOGOUT</a>

    <div class="card mt-2">
    	<div class="card-body">
    		<?php
    		$file = @$_GET['url'];
    		if(empty($file)){
    			echo "<h4>selamat datang siswa</h4>";
    			echo "aplikasi pembayaran spp";
    			echo "<hr>";
    			include'history-pembayaran.php';
    		}else{
    			include $file.'.php';
    		}

    		 ?>
    		
    	</div>
    </div>

</div>

<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>